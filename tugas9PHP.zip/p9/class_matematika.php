<?php
    class Matematika {
        // Konstanta class
        const PHI = 3.14;

        // static member variable
        public static $counter = 100;

        // static member function
        public static function tambahkan($a, $b) {
            return $a + $b;
        }
        
        // akses member variable dari dalam class
        public static function naikanCounter() {
            // Menambahkan nilai counter
            self::$counter++;
        }

        // akses konstanta class
        public static function luaslingkaran($jari) {
            // Menambahkan return untuk mengembalikan nilai luas
            $luas = self::PHI * $jari * $jari;
            return $luas;
        }
    }

    // Contoh penggunaan
    Matematika::naikanCounter(); // Memanggil fungsi untuk menaikkan nilai counter
    echo Matematika::$counter; // Menampilkan nilai counter setelah peningkatan
?>