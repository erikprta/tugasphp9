<?php
    class Matematika {
        const PHI = 3.14;

        public static function luaslingkaran($jari)
        {
            $luas = self::PHI * $jari * $jari;
            return $luas;
        }
    }
    echo 'NILAI PHI '. Matematika::PHI ;
    $luasling = Matematika::luaslingkaran(8);
    echo 'Luas Lingkaran Jari 8 = ' . $luasling;
?>